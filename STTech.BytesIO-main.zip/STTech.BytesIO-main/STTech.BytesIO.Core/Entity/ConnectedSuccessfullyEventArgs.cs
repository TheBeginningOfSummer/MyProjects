﻿using System;

namespace STTech.BytesIO.Core
{
    public class ConnectedSuccessfullyEventArgs : EventArgs
    {
        public ConnectedSuccessfullyEventArgs()
        {
        }
    }
}
