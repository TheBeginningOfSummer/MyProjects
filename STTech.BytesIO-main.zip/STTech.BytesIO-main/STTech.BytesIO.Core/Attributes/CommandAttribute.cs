﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace STTech.BytesIO.Core.Attributes
//{
//    /// <summary>
//    /// 命令
//    /// </summary>
//    [AttributeUsage(AttributeTargets.Method)]
//    public class CommandAttribute: Attribute
//    {
//        /// <summary>
//        /// 显示名
//        /// </summary>
//        public string DisplayName { get; set; }

//        /// <summary>
//        /// 命令
//        /// </summary>
//        /// <param name="displayName">显示名称</param>
//        public CommandAttribute(string displayName)
//        {
//            DisplayName = displayName;
//        }
//    }
//}
